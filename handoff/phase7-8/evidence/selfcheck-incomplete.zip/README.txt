Diagnostic bundle; no automatic upload. Check paths/text in logs before sharing.
Complete=false
Doctor incomplete or --plan-only: no rendered draft, no visual frames, no TTS verification
Windows visual review/listening and real rendered timings remain unverified
